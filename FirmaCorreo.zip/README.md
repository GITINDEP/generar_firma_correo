# generar_firma_correo
Aplicativo para la generación de las firmas de los correos electrónicos, con acceso por Active Directory
